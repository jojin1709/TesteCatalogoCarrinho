package com.exemplo.dominio;

public class Carrinho {
}
