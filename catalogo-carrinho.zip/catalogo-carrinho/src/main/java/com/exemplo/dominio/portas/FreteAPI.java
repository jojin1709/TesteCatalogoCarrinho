package com.exemplo.dominio.portas;

public class FreteAPI {
}
