package com.exemplo.dominio.portas;

public class EstoqueRepository {
}
