package com.exemplo.dominio.adaptadores;

public class StubEmailService {
}
