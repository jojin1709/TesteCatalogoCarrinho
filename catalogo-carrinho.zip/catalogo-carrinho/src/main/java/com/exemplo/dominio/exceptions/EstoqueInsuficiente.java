package com.exemplo.dominio.exceptions;

public class EstoqueInsuficiente {
}
