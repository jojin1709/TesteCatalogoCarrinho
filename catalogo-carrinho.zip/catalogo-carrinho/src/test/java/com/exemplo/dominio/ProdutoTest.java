package com.exemplo.dominio;

public class ProdutoTest {
}
