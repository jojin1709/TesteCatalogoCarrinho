package com.exemplo.dominio;

public class IntegracaoSimuladaTest {
}
