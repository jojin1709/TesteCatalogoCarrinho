package com.exemplo.dominio;

import com.exemplo.portas.EstoqueRepository;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

public class Carrinho {

    public static class Item {
        public final Produto produto;
        public int quantidade;

        public Item(Produto produto, int quantidade) {
            this.produto = produto;
            this.quantidade = quantidade;
        }

        public BigDecimal subtotal() {
            return produto.getPreco().multiply(BigDecimal.valueOf(quantidade));
        }
    }

    private final Map<String, Item> itens = new LinkedHashMap<>();
    private final EstoqueRepository estoque;
    private Cupom cupom;
    private PromocaoProgressiva promocao;

    public Carrinho(EstoqueRepository estoque, PromocaoProgressiva promocao) {
        this.estoque = estoque;
        this.promocao = promocao;
    }

    public void aplicarCupom(Cupom cupom) {
        this.cupom = cupom;
    }

    public void adicionar(Produto produto, int quantidade) {
        if (quantidade <= 0) throw new IllegalArgumentException("Quantidade inválida");
        boolean reservado = estoque.reservar(produto.getId(), quantidade);
        if (!reservado) throw new IllegalStateException("Estoque insuficiente");

        Item item = itens.get(produto.getId());
        if (item == null) {
            itens.put(produto.getId(), new Item(produto, quantidade));
        } else {
            item.quantidade += quantidade;
        }
    }

    public void remover(String produtoId, int quantidade) {
        Item item = itens.get(produtoId);
        if (item == null || quantidade <= 0 || quantidade > item.quantidade)
            throw new IllegalArgumentException("Remoção inválida");

        item.quantidade -= quantidade;
        estoque.liberar(produtoId, quantidade);

        if (item.quantidade == 0) {
            itens.remove(produtoId);
        }
    }

    public BigDecimal total(LocalDate hoje, String cepDestino, BigDecimal pesoKg, FreteRegra freteRegra) {
        int qtdTotal = itens.values().stream().mapToInt(i -> i.quantidade).sum();
        BigDecimal descontoPromo = promocao.descontoPercentual(qtdTotal);

        BigDecimal subtotal = itens.values().stream()
                .map(Item::subtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal comDesconto = subtotal.multiply(BigDecimal.ONE.subtract(descontoPromo));

        if (cupom != null) {
            comDesconto = cupom.aplicar(comDesconto, hoje);
        }

        BigDecimal frete = freteRegra.calcular(cepDestino, pesoKg);
        return comDesconto.add(frete);
    }
}
