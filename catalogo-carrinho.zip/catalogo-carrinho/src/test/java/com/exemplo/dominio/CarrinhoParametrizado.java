package com.exemplo.dominio;

public class CarrinhoParametrizado {
}
