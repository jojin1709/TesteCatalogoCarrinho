package com.exemplo.dominio.portas;

public class EstoqueRepositoyStubTest {
}
